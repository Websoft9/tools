
<div class="aligncenter">
    <?php xdocs_the_quick_links(); ?>
    <?php xdocs_the_copyrights(); ?>
</div>
    <!--=================================
    Script Source
    =================================-->
    <script type="text/javascript" src="<?php xdocs_path();?>/js/bootstrap.js"></script>
    <script type="text/javascript" src="<?php xdocs_path();?>/js/prism.js"></script>
    <script type="text/javascript" src="<?php xdocs_path();?>/js/main.js"></script>
    <?php xdocs_foot(); ?>
    </body>

</html>