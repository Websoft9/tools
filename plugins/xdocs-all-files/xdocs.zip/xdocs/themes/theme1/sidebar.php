<aside class="main-sidebar">
  <?php xdocs_the_quick_links(); ?>
  <?php xdocs_logo(); ?>

  <!-- sidebar: style can be found in sidebar.less -->
  <div class="sidebar" id="scrollspy">
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="nav sidebar-menu">
      <li class="active"><a href="#introduction">Introduction</a>

                  <?php 
                   if( have_rows('add_sections',$post_id) ):
                         $i = 0;
                          while( have_rows('add_sections',$post_id) ): the_row(); 
                              $section_title  =   get_sub_field('section_title');  
                              $slug = sanitize_title($section_title);
                
                            $i++;
                            if($i == 1){
                              $active = 'active';
                            }else{
                              $active = '';
                            }
                   ?>

                 <?php  if( have_rows('steps',$post_id) ): ?>

                   <li class="treeview" id="scrollspy-components"><a href="#<?php echo $slug; ?>"><?php echo $section_title; ?></a>
                  <?php 


                    echo  '<ul class="nav treeview-menu">';
                      // loop through rows (sub repeater)
                      while( have_rows('steps',$post_id) ): the_row();
                      $step_slug = sanitize_title(get_sub_field('step_title'));
                         echo '<li class=""><a href="#'.$step_slug.'">'. get_sub_field('step_title') .'</a>';
                       endwhile; 
                      echo '</ul>';
                  ?>
                </li>

              <?php else: ?>
            

               <li class=""><a href="#<?php echo $slug; ?>"><?php echo $section_title; ?></a>

                    <?php endif; ?>

              <?php endwhile; endif;?>

            </ul>
          </div>
    </aside>