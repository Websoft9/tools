
  <footer class="main-footer">

      <div class="pull-right hidden-xs">
          <?php xdocs_the_version(); ?>
      </div>

    <?php xdocs_the_copyrights(); ?>
  </footer>


</div><!-- ./wrapper -->


    <script type="text/javascript" src="<?php echo plugin_dir_url(__FILE__ ); ?>/assets/js/jQuery-2.2.0.min.js"></script>
    <script type="text/javascript" src="<?php echo plugin_dir_url(__FILE__ ); ?>/assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo plugin_dir_url(__FILE__ ); ?>/assets/js/prism.js"></script>
  <?php xdocs_foot(); ?>
  </body>
</html>