
  <footer class="main-footer">

      <div class="pull-right hidden-xs">
          <?php xdocs_the_version(); ?>
      </div>

    <?php xdocs_the_copyrights(); ?>
  </footer>


</div><!-- ./wrapper -->


    <script type="text/javascript" src="<?php  xdocs_path();?>/js/jQuery-2.2.0.min.js"></script>
    <script type="text/javascript" src="<?php  xdocs_path();?>/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php  xdocs_path();?>/js/app.js"></script>
    <script type="text/javascript" src="<?php  xdocs_path();?>/js/jquery.stickem.js"></script>
    <script type="text/javascript" src="<?php  xdocs_path();?>/js/jquery.slimscroll.min.js"></script>
    <script type="text/javascript" src="<?php  xdocs_path();?>/js/prism.js"></script>
    <script type="text/javascript" src="<?php  xdocs_path();?>/js/docs.js"></script>
  <?php xdocs_foot(); ?>
  </body>
</html>