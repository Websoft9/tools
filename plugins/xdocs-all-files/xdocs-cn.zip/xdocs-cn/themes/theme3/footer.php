

<footer class="bs-docs-footer" role="contentinfo">
    <div class="container">
        <?php xdocs_logo(); ?>
        <?php xdocs_the_quick_links(); ?>
        <p> <?php xdocs_the_copyrights(); ?></p>


    </div>

</footer>
<script src="<?php xdocs_path();?>/js/jquery.js"></script>
<script src="<?php xdocs_path();?>/js/bootstrap.js"></script>
<script type="text/javascript" src="<?php xdocs_path();?>/js/prism.js"></script>
<script src="<?php xdocs_path();?>/js/docs.js"></script>
<script src="<?php xdocs_path();?>/js/ie10-viewport-bug-workaround.js"></script>

<?php xdocs_foot(); ?>
</body>
</html>
